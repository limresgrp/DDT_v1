Drug Discovery Tool - DDT

Studying ligand-receptor complexes using VMD

INSTALLATION GUIDE
===============================================================================

Requirements
-------------------------------------------------------------------------------

-VMD 1.9.1 or later


Installation
-------------------------------------------------------------------------------

You will need write privileges in VMD's program directory.

1. Extract the distribution archive.

2. Copy the DDT subfolder (NOT the whole DDT-release distribution folder!)
   into $VMDDIR/plugins/noarch/tcl/

3. Copy the file loadDDT.tcl into the $VMDDIR/scripts/init.d/
   folder (create such folder if it does not exist).

The plugin should appear in the "Extensions" menu upon VMD's next run.


Usage without installation
-------------------------------------------------------------------------------

As a last resort, the DDT plugin may be loaded without installation by issuing
a "source $VMDDIR/plugins/noarch/tcl/DDT/ddt.tcl" command in the TK console.


Problem with Unix distribution
-------------------------------------------------------------------------------

If even the "source $VMDDIR/plugins/noarch/tcl/DDT/ddt.tcl" command fails, you
have to copy the directory tooltip/ and bwidget-1.9.11/ inside the directories
$VMDDIR/scripts/tcl8.5 and $VMDDIR/scripts/tcl8/8.x (x= 3,4,5)

